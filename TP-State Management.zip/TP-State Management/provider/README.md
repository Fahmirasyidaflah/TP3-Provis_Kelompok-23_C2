# Flutter Provider Online Store

Sample apps using provider state management, http, fakeapi.platzi.com study case online store

## Youtube Link

[![Watch the video](https://img.youtube.com/vi/f55_5wnq6as/sddefault.jpg)](https://youtu.be/f55_5wnq6as)

https://youtu.be/f55_5wnq6as

## ScreenShot

| Home        | Detail    |
|--------------|-----------|
| <img src="1.png" width="300"/> | <img src="2.png" width="300"/>      |

## Contact:
* Consultation Flutter and Endorse https://t.me/bahri_bhe
* Youtube: https://youtube.com/@codewithbahri
* Github: https://github.com/bahrie127
* Linkedin: https://linkedin.com/in/bahrie
* Roadmap Flutter: https://youtu.be/e2zMJqDBmoY
* Medium: https://medium.com/@bahri

