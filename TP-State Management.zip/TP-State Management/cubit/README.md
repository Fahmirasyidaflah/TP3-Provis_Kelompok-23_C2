# Flutter Cubit Online Store

Sample apps using cubit by flutter bloc, http, fakeapi.platzi.com study case online store

## Youtube Link

[![Watch the video](https://img.youtube.com/vi/kQ1pScycmYM/sddefault.jpg)](https://youtu.be/kQ1pScycmYM)

https://youtu.be/kQ1pScycmYM

## ScreenShot

| Home        | Detail    |
|--------------|-----------|
| <img src="1.png" width="310"/> | <img src="3.png" width="310"/>      |

## Contact:
* Consultation Flutter and Endorse https://t.me/bahri_bhe
* Youtube: https://youtube.com/@codewithbahri
* Github: https://github.com/bahrie127
* Linkedin: https://linkedin.com/in/bahrie
* Roadmap Flutter: https://youtu.be/e2zMJqDBmoY
* Medium: https://medium.com/@bahri

